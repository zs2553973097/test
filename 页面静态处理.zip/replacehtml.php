<?php
require 'db_config.php';
require 'mysqli.class.php';
define("HTTP", "http://www.hdkehuan.com");

/*数据库数据替换模板页测试，by湖南凤凰张卫平*/
$sql = "select * from my_movie";
$res = DB()->sqlQuery($sql);
$row = DB()->fetchList();
$count = count($row);
echo "数据条数为：".$count;


    $page = 1;
    $dir = dirname(__FILE__);
    $viewpath = $dir."\\movie\\replace.html";
    //echo $viewpath;
    $content = file_get_contents($viewpath);//模板文件路径可以通过form提交过来
    //echo $content;
    $tempcontent = $content;
    foreach($row as $key=>$val)
    {
        
        $rep_name = $val["sname"];
        $rep_category = $val["category"];
        $rep_img = HTTP.$val["img"];
        $rep_time = $val["create_time"];
        $rep_time = date("Y-m-d H:i:s",$rep_time);
        //echo $rep_name;
        
        
        $rep1 = str_replace("rep_name", $rep_name, $content);//替换html文件里的标志
        $rep2 =str_replace("rep_category", $rep_category, $rep1);
        $rep3 = str_replace("rep_img", $rep_img, $rep2);
        $rep4 = str_replace("rep_time", $rep_time, $rep3);
        $infoPage = "\\movie\\info";
        if(!file_exists($dir.$infoPage))//生成页面路径,如果要重新生成，取消判断就行
        {
            mkdir($dir.$infoPage);
        }
        $filename = $dir.$infoPage."\\infopage_".$page.".html";
        file_put_contents($filename, $rep4);
        $content = $tempcontent;
        $page=$page+1;
        echo "</br>第".$page."页".$filename."生成成功！</br>";
    }
    

/*
$sql = "select * from my_movie";
$res = DB()->sqlQuery($sql);

$row = DB()->fetchOne();
echo "单条数据：<pre>";
print_r($row);
echo "</pre>";

DB()->setCursor(0);
$row =DB()->fetchList();
foreach ($row as $v)
{
    echo "数组数据：<pre>";
    print_r($v);
    echo "</pre>";
}
 */


