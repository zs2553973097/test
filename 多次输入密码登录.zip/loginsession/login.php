

<script src="../../../../loginsession/js/jquery-1.11.1.js" ></script>
<div>
    <input type ="text" id="password" name="password" value="" />
        </br>
    <input type ="button" id ="login" value="提交口令" onclick="ajaxlogin();" />
    
</div>
<div id ="content"></div>
<script>
    num = 0;
    
    function aajaxlogin()
    {
        alert("begin");
    }
    function ajaxlogin()
    {
        //alert("submit");
        var password = $("#password").val();
        $.ajax({
            url:"sessionlogin.php",
            type:"post",
            data:"password="+password+"&num="+num,
            //datatype:"json",
            success:function(msg)
            {
                var msg = JSON.parse(msg);
                alert(msg.info);
                num = num + 1;
                if(num==5)
                {
                    $("#content").html(msg.info);
                }
            },
            error:function()
            {
                alert("提交出错！");
            }
                    
        });
        
    }
</script>
