<?php
session_start();
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function dologin($wordarr)
{
    $num = $_POST["num"];
    if(isset($_POST["password"])&&$num<5)
    {
        
        $password = $_POST["password"];
        $_SESSION["password"][$num] = $password;
        if($_SESSION["password"][$num]==$wordarr[$num])
        {
            $_SESSION["success"][] = true;
            $numstr = "ok,第".($num+1)."次提交口令正确！";
            $result = array("status"=>200,"info"=>$numstr,"successpassword"=>$password,"输入次数"=>$num+1);
            if(($num+1)!=5)
            {
                $code = json_encode($result);
                 
                echo  $code;
            }
            
        }else
        {
            $_SESSION["success"][] = false;
            $numstr = "fail,第".($num+1)."次提交口令错误！";
            $result = array("status"=>400,"info"=>$numstr,"failpassword"=>$password,"输入次数"=>$num+1);
            if(($num+1)!=5)
            {
                $code = json_encode($result);
            
                echo $code;
            }
            
        }
    }
        
}
$wordarr = array("1","11","111","1111","11111");
dologin($wordarr);
$flag = false;

if(isset($_SESSION["success"])&&count($_SESSION["success"])==5)
{
    foreach ($_SESSION["success"] as $val)
    {
        if($val==false)
        {
            $flag = true;
            unset($_SESSION["success"]);
            echo json_encode(array("info"=>"你的尝试失败！,可以刷新从新尝试！"));
            break;
        }
    }
    if($flag == false)
    {
        unset($_SESSION["success"]);
        echo json_encode(array("info"=>"你成功打开了五个密码！然后可以做你想做的事情！"));
        
    }
}


