<?php

/* 
湖南凤凰张卫平2017/5/2
 *字符串加解密测试类，先构筑出原始字符表，每个字符的位置对应随机产生的编码序号，
 * 
 */
class secret
{
    public $encode = array(
        "/601","/211","/433","/478","/5217","/6002","/789","/2458","/039","/10121",
        "/1821","/1242","/1123","/4134","/15","/16","/17","/18","/19","/20",
        "/21","/22","/23","/24","/25","/26","/27","/28","/29","/30",
        "/31","/32","/33","/34","/35","/36","/37","/38","/39","/40",
        "/41","/42","/43","/44","/45","/46","/47","/48","/49","/50",
        "/51","/52","/53","/54","/55"
        );//这个encode不会在本类中使用，留着可以以后使用
    public $decode = array(
        "a","b","c","d","e","f","g","h","i","j",
        "k","l","m","n","o","p","q","r","s","t",
        "u","v","w","x","y","z","<",">","?"," ",
        "~","!","@","#","$","%","^","&","*","(",
        ")","_","+","{","}","[","]",";",":","'",
        "A","B","C","D","E","F","G","H","I","J",
        "K","L","M","N","O","P","Q","R","S","T",
        "U","V","W","X","Y","Z","|","\\",",",".",
        "/","\r","\n"//"0","1","2","3","4","5","6","7","8","9"
        );
    public $size = 0;
    public $filename = "文件名";
    public $filedir = "文件路径";
    public $keyhas = array();
    public $keynohas = array();
    public $keyall = 0;
    public $a;
    public $b;
    public function __construct($filename="",$filedir="") {
        
        $this->filename = $filename;
        $this->filedir = $filedir;
        $this->size = count($this->decode);
        
    }
    
    public function getDecode()
    {
        return $this->decode;
    }

    public function my_sort($a,$b)//处理数组为升序
    {
    if ($a==$b) return 0;
        return ($a<$b)?-1:1;
    }

        public function encode($encode="")//
    {
        $filename = $this->filename;
        $filedir = $this->filedir;
        $decode = $this->decode;
        $size = $this->size;
        //chdir($filedir);
        
        $reordering = array();
        try 
        { 
            $handle = fopen($filedir."\\".$filename, "r");
            echo "</br>类中打开的文件名：</br>";
            echo $filedir."\\".$filename;
            echo "</br>";
            if($handle)
            {
                //var_dump($handle);
                $find = array();
                $nofind = array();
                $original = array();
                $sn = 0;//记录不在字符集表中的字符位置
                $char = fgetc($handle);
                $tempchar = null;
                $add = 0;
                while(!feof($handle))
                {
                    //$char = fgetc($handle);
                    if(!feof($handle))
                    {
                        //echo $char;
                        $flagfind = false;
                        
                        for($i=0;$i<$size;$i++)
                        {
                            if($decode[$i]==$char&&$tempchar!=$char)//找到了字符，并且和前一个字符不同
                            {
                                //$add = $i;
                                $tempchar = $char;
                                $find[$i] = $char;//找到的字符串
                                $firstfind[$add] = $i;//把找到的字符串序号存储下来
                                $add = $add + 1;//存在的字符序号自增
                                $flagfind = true;
                                break;
                            } else 
                                if($decode[$i]==$char&&$tempchar==$char)//找到了字符，并且和前一个字符相同
                                {
                                    $firstfind[$add] = $i;
                                    $add = $add + 1;
                                    $flagfind = true;
                                    break;
                                }
                        }
                        if($flagfind == false)
                        {
                            /*
                            if(strlen($char)==1)
                            {
                                $nofind[$sn] = $char;//把没有找到的字符串存储下来
                                $add = $add +1;
                            }else
                            {
                                $nofind[$sn] = $char;//把没有找到的字符串存储下来
                                $add = $add +1;
                                $sn = $sn+1;
                            }
                            */
                            
                            //if(strlen($char)==1)
                            {
                                $nofind[$sn] = $char;//把没有找到的字符串存储下来
                                $add = $add + strlen($char);//汉字的长度也一起记录下来
                            }
                            
                             
                            //echo $char;
                        }
                        
                    }
                    $char = fgetc($handle);//取下一个字符
                    $sn = $sn + 1;//不存在的字符序号自增
                }
                fclose($handle);
                $result1 = array();
                $result2 = array();
                //$keyfind = array_keys($firstfind);
                //$keynofind = array_keys($nofind);
                
                /*调试点，可以自己打开
                echo "</br>查找到的字符串数组：</br>";
                print_r($find);
                echo "</br>******************</br>";
                
                echo "</br>找到的字符串对应decode编码位置的数组：</br>";
                print_r($firstfind);
                echo "</br>***********************</br>";
                
                echo "</br>没有找到的字符串对应位置的数组：</br>";
                print_r($nofind);
                echo "</br>***************************</br>";
                */
                
                
                foreach ($firstfind as $k=>$v)
                {
                    $result1[$k] = $encode[$v];
                    $this->keyhas[] = $k;
                }
                /*
                echo "</br>对应自己制定编码表的位置<pre></br>";
                print_r($result1);
                echo "</pre></br>*********************************";
                */
                /*
                foreach ($keynofind as $k=>$v)
                {
                    $result2[$k] = $k;
                    $this->keynohas[] = $k;
                }
                */
                $result2 = $nofind;
                /*
                echo "</br>没找到的字符串对应位置数组</br>";
                print_r($result2);
                echo "</br>*********************************";
                */
                $result = ($result1+$result2);
                $result = ($result);
                //$mysort = get_class_methods($this);
                //echo "</br><methods></br>";
                //print_r($mysort);
                //exit;
                uksort($result,array('secret','my_sort' ));
                //这个方法的回调格式要记住
                /*
                echo "</br>合并找到和没找到字符串，最终位置对应编码的结果</br>";
                print_r ($result);
                echo "</br>*******************************";
                echo "</br>";
                */
                $i = 0;
                $this->keyall = count($result);
                foreach ($result as $key=>$val)
                {
                    $val = $val;// ^ 9;
                    $doval = $val;// >> 2;
                    $reordering[$i] = $doval;
                    $i = $i + 1;
                }
            }
        }
        catch(Exception $e) 
        { 
            echo "处理文件有错";
            
        }
        
        return $reordering; 
    }
    public function dynamicCode()//动态产生随机数编码，5位数的，可以自己修改位数
    {
        $num = $this->size;
        $encode = array();
        $flag = true;
        for($i=0;$i<$num;$i++)//第一次产生随机数，5位
            {
                $myword = rand(10000, 99999);
                $encode[] = $myword;
            }
            //print_r($encode);
            //exit();
        while($flag)//过滤重复的随机数，有则重新产生
        {
            
            for($n=0;$n<$num-1;$n++)//取得前一个元素
            {
                $tempencode = $encode[$n];
                for($m=$n+1;$m<$num;$m++)//头一个元素对比后面所有的元素
                {
                    if($tempencode==$encode[$m])
                    {
                        $flag = true;
                        break;
                    }else
                    {
                        $flag = false;
                    }
                }
                if($flag == true)//重新产生
                {
                    $encode[$n] = rand(10000,99999);
                    break;
                }else
                {
                    continue;
                }
            }
            $n=0;
        }
        /*
        echo "</br>****************************打印加密编码序列******************************</br>";
        echo "<pre>";
        print_r($encode);
        echo "</pre>";
        echo "</br>***********************************************************************</br>";
        */
        return $encode;
    }
    public function dynamicDecode($content)
    {
        //$encode = $this->dynamicCode();
        $keyhas = $this->keyhas;
        $keynohas = $this->keynohas;
        $keyall = $this->keyall;
        $size = strlen($content);
        $size = $size/5;
        if($size!=$keyall)
        {
            echo "</br>原始文件长度为：".$keyall."</br>";
            echo "</br>加密后的文件长度为：".$size."</br>";
            echo "</br>加密后的文件长度和原来的文件不同，请检查错误后再试！！</br>";
            exit;
        } else {
            echo "</br>文件长度为:".$size.";长度相同，可以解密！</br>";
        }
        $arrsource = array();
        for($i=0;$i<$size;$i++)
        {
            $arrsource[$i] = substr($content, $i*5,5); 
        }
        
        /*
        echo "<pre>";
        print_r($arrsource);
        echo "</pre>";
        */
        
        $endresult = array();
        foreach($arrsource as $key=>$val)
        {
            //foreach($)
            //$temp = $arrsource[$i] ;//<< 2;
            //$temp = $temp;//^ 9;
            /*
            if(array_key_exists($key, $keyhas))
            {
                $endresult[$key] = chr($val);
                //continue;
            }
            if(array_key_exists($key,$keynohas))
            {
                $endresult[$key] = $val;
                //continue;
            }
            */
        }
        return $endresult;
    }
}
