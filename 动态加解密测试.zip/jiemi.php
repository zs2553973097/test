<?php
session_start();
/* 
湖南凤凰张卫平2017/5/4
 * 测试解密动态加密的文件，分两种形式，一种是session存储编码，一种是file存储编码，
 * $cacheflag变量是切换标志，使用时，请自行切换。如果是file存储方式，会需要四个加密
 * 后产生的解密文件，分别是decode.txt,dynamicEncode.txt,jiemiFile.txt,lastContent.txt,
 * 如果网站文件是移动性质的解密，请把jiemi.php和上面四个文件拷贝到要移动到的www目录里，
 * 并且拷贝jiami和jiemi目录到www目录中，解密过后，项目文件夹将会生成在jiemi文件夹下。
 */

//$cacheflag = "nofile";//切换测试标志，值file默认用文件方式，nofile采用session方式
$cacheflag = "file";//切换测试标志，值file默认用文件方式，nofile采用session方式

$jiemiFile = array();
$dynamicEncode = array();
$lastContent = array();
$decode = array();
if($cacheflag!="file"&&isset($_SESSION["jiemiFile"]))//判断是否使用session方式解密
{
    $jiemiFile = $_SESSION["jiemiFile"];
    $dynamicEncode = $_SESSION["dynamicEncode"];
    $lastContent = $_SESSION["lastContent"];
    $decode = $_SESSION["decode"];
}
if($cacheflag=="file")//判断是否文件解密方式
{
    //$jiemiFile = file("jiemiFile.txt");
    $str = file_get_contents("jiemiFile.txt");
    $jiemiFile = explode("split", $str);
    unset($jiemiFile[count($jiemiFile)-1]);//处理数组最后一个空数据
    
    $str = file_get_contents("dynamicEncode.txt");
    $arrflag = explode("flag", $str);
    foreach ($arrflag as $val)
    {
        $dynamicEncode[] = explode("split", $val);
    }
    /*
    $dynamicEncodeSource = file("dynamicEncode.txt");//处理flag分割符号
    $n = 0;
    $num = count($dynamicEncodeSource);
    $dynamicEncodeDest = array();
    for($i=0;$i<$num;$i++)
    {
        if($dynamicEncodeSource[$i]==="flag\n")
        {
            //echo "</br>打印动态数组begin:".$dynamicEncodeSource[$i]."</br>";
            //unset($dynamicEncodeDest[$n]);
            $dynamicEncode[] = $dynamicEncodeDest;
            $dynamicEncodeDest = null;
            $n = 0;
        }else
        {
            $dynamicEncodeDest[$n] = $dynamicEncodeSource[$i];
            //echo "</br>打印动态数组end:".$dynamicEncodeDest[$n]."</br>";
            $n = $n+1;
        }
    }
    */
    ///////////////////////////////////
    $str = file_get_contents("lastContent.txt");
    $arrflag = explode("flag", $str);
    foreach ($arrflag as $val)
    {
        $lastContent[] = explode("split", $val);
    }
    /*
    $lastContentSource = file("lastContent.txt");//处理flag分割符号
    $n = 0;
    $num = count($lastContentSource);
    //echo "numlastContent:".$num;
    $lastContentDest = array();
    
    for($i=0;$i<$num;$i++)
    {
        //echo "</br>lastContent:".$i."</br>";
        $lastContentDest[$n] = $lastContentSource[$i];
        if($lastContentSource[$i]=="flag\n")
        {
            //echo "</br>打印动态数组begin:".$lastContentSource[$i]."</br>";
            //unset($dynamicEncodeDest[$n]);
            $lastContent[] = $lastContentDest;
            $lastContentDest = null;
            $n = 0;
        }else
        {
            $lastContentDest[$n] = $lastContentSource[$i];
            //echo "</br>打印动态数组end:".$dynamicEncodeDest[$n]."</br>";
            $n = $n+1;
        }
    }
    */
    //$decode = file("decode.txt");
    $str = file_get_contents("decode.txt");
    $decode = explode("split", $str);
}


    $size = count($jiemiFile); 
    echo "</br>加密过的文件</br>";
    echo "<pre>";
    print_r($jiemiFile);
    echo "</pre>";
    /*
    echo "</br>session中的encode</br>";
    echo "<pre>";
    print_r($dynamicEncode);
    echo "</pre>";
    echo "</br>加密字符串</br>";
    echo "<pre>";
    print_r($lastContent);
    echo "</pre>";
    echo "</br>解密编码</br>";
    echo "<pre>";
    print_r($decode);
    echo "</pre>";
    */
    //exit;
    $size = count($jiemiFile);
    for($i=0;$i<$size;$i++)
    {
        $arrtemp = null;
        $file = $jiemiFile[$i];
        //echo "</br>filename:".$file."</br>";
        //$file = str_replace("\n", "",$file);
        //if(!empty($file))
        $handle = fopen($file, "w",true);
        if($handle)
        {
            $encode = $dynamicEncode[$i];
            $content = $lastContent[$i];
            $tempstr = "";
            foreach($content as $key=>$val)
            {
                ////
                {
                    /*
                    echo "</br>";
                    echo "key:".$key."=>".$val;
                    echo "</br>";
                    */
                    //$val = $val <<2;
                    //$val = $val^9;
                    /*
                    if($cacheflag=="file")
                    {
                        $val = str_replace("\n", "", $val);
                    }
                    */
                    if(strlen($val)==5)
                    {
                        //echo "</br>encode:</br>";
                        //print_r($encode);
                        $name = array_search($val,$encode);
                        //echo "</br>在编码中的序号：".$name;
                        //echo"</br>endsearchencode</br>";
                        $name = $decode[$name];
                        //$arrtemp[$key] = $name;
                        $tempstr .= $name;
                        /*
                        echo "</br>";
                        echo "字符串:".$name;
                        echo "</br>";
                        */
                        $name = "";
                    }else 
                    {
                        
                        //$arrtemp[$key] = $val;
                        $tempstr .= $val;
                    }
                    
                }
            }
        }
        //echo "content:".$tempstr;
        fwrite($handle, $tempstr);
        //if($handle)
        fclose($handle);
    }
    echo "</br>************************解密文件结束***********************</br>";
    
        
    
    

