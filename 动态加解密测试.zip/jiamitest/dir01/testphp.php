<?php
function testjiami()
{
    return "<span style='color:red;'>加密测试  加密测试！！！</span>";
}
for($i=0;$i<100;$i++)
{
    echo $i;
}
echo testjiami();