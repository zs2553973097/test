<?php

/* 
湖南凤凰张卫平2017/5/1
 * 加密测试文件，每次测试将会生成不同加密编码，已经加密过的文件，将不会继续加密。如果想动态加密，请每次测试时，
 * 关闭浏览器，并且重启apache服务，这样将会清空session，我没有设置session的到期时间，目前只能这样每次产生不同
 * 的加密代码。对应文件存储编码的解密方式，将会产生四个文件，分别是decode.txt,dynamicEncode.txt,jiemiFile.txt,lastContent.txt，
 * 具体怎样使用，请看说明或者jiemi.php中的帮助。
 */
session_start();
require  'jiamei.class.php';
$num = 0;
$arrfind = array();
$arrall = array();
function ergodic($dir,$dot)
{
    global $num;
    global $arrfind;
    global $arrall;
    global $all;
    if(is_dir($dir)&&$dot!="."&&$dot!="..")
    {
        $handle = opendir($dir);
        $file = false;
        while(($file= readdir($handle))!==false)
        {
            if($file!=='.'&&$file!=='..'&&is_dir($dir.$file))
            {
                //echo $file."</br>"; 
                ergodic($dir.$file.'/',$file);
               
            }else
            {
                
                $find = $dir.$file;
                $length = strlen($find);
                if(!stripos($find, ".", $length-1)>0)
                {
                    $num = $num + 1;
                    //echo "</br>";
                    //echo "first".$dir.$file;
                    //echo "</br>";
                    if(
                        stripos($find, ".php",$length-4)>0
                        ||stripos($find, ".txt",$length-4)>0
                        || stripos($find, ".html",$length-5)>0
                            )
                    {
                        $arrfind[] = $find;
                    } else {
                        //$all[] = $find;
                        
                    }
                    $arrall[] = $find;
                    
                }        
                
                
            }
        }
        closedir($handle);
    }else
    {
        /*
        echo "</br>";
        echo "next:".$dir;
        echo "</br>";
        */
    }
    //echo "</br>";
    //echo $num;
    //echo "</br>";
    return $num;
}



$dir = "/jiamitest/";//项目文件夹名称，测试请把需要加密的文件放在这个目录里,可以包含目录与文件，真正使用时，写入项目文件夹名称就行
$begindir = dirname(__FILE__);
$dir = $begindir.$dir;
echo "遍历目录".$dir."下的文件:</br>";

$num = ergodic($dir,"");
echo "文件总数:".$num;
echo "</br>*********************************************************************</br>";
foreach ($arrall as $allfile)
{
    echo "</br>";
    echo $allfile;
    echo "</br>";
}
echo "</br>*********************************************************************</br>";
echo "查找到可以加密的文件总数为:".count($arrfind);
echo "</br>查找到可以加密的文件为:</br>";
echo "<pre>";
print_r($arrfind);
echo "</pre>";
echo "</br>*********************************************************************</br>";

foreach ($arrall as $first)
{
    $length = strlen($first);
    if(!stripos($first, ".php",$length-4)>0&&!stripos($first, ".txt",$length-4)>0
                && !stripos($first, ".html",$length-5)>0)
    {
        $pos = stripos($first, "/");
        $dirtemp = substr($first,0, $pos);
        $filetemp = substr($first, $pos, strlen($first)-1);
        $fileend = strrchr($first, "/");
        $dirmid = substr($first,strlen($dirtemp),strlen($first)- strlen($fileend)- strlen($dirtemp));
        $dirmid = str_replace("/", "\\", $dirmid);
        $fileend = str_replace("/", "\\", $fileend);
        
        /*
        echo "</br>dirtemp:".$dirtemp."</br>";
        echo "</br>dirmid:".$dirmid."</br>";
        echo "</br>fileend:".$fileend."</br>";
        */
        $dirend = $dirtemp."\jiemi".$dirmid;
        if(!file_exists($dirend))
        {
            mkdir($dirend,0777,true);
        }
        copy($first, $dirend.$fileend);
    }
}
//exit;
$alreadyrun = array();
$readyrun = $arrfind;
//unset($_SESSION["run"]);
//unset($_SESSION["dynamicEncode"]);
//unset($_SESSION["lastContent"]);
if(isset($_SESSION["run"]))
{
    if(isset($_SESSION["jiemiFile"]))
    {
        unset($_SESSION["jiemiFile"]);
    }
    if(isset($_SESSION["dynamicEncode"]))
    {
        unset($_SESSION["dynamicEncode"]);
    }
    if(isset($_SESSION["lastContent"]))
    {
        unset($_SESSION["lastContent"]);
    }
    $run = $_SESSION["run"];
    echo "</br>已经处理过的文件如下:</br>";
    echo "<pre>";
    print_r($run);
    echo "</pre>";
    foreach ($run as $val)
    {
        $alreadyrun[] = $val;
    }
    $readyrun = array_diff($arrfind, $alreadyrun);//对比数组，得出需要处理的元素
    echo "</br>对比已经处理过的文件完成,还需要处理的文件如下:</br>";
    echo "<pre>";
    print_r($readyrun);
    echo "</pre>";
}

$i = 0;
$donum = 0;
//$_SESSION["dynamicEncode"] = null;
if($readyrun==array())
{
    echo "所有文件已经处理过了";
    exit;
}
foreach ($readyrun as $file)
{
    echo "</br>";
    echo "正在处理的文件名为:".$file;
    echo "</br>";
    
    
    
    $pos = stripos($file, "/");
    $destfile = substr($file, $pos);
    $rootdir = substr($file,0,$pos);
    //$rootdir = str_replace("\\", "/", $rootdir);
    //echo "rootdir:".$rootdir;
    
    $_SESSION["run"][] = $file;
    $file = str_replace("\\", "/", $file);
    //echo "</br>*****文件路径：".$file."*****</br>";
    $filename = strrchr($file, "/");
    //echo "</br>*****文件名".$filename."*****</br>";
    $dirpos = strrpos($file,$filename);
    $filedir = substr($file,0, $dirpos);
    $filedir = str_replace("/", "\\", $filedir);
    //echo "</br>*****文件路径".$filedir."*****</br>";
    $filename = substr($filename, 1);
    
    $do = new secret($filename,$filedir);//实例化
    $_SESSION["decode"] = $do->getDecode();
    $arrsplit = $_SESSION["decode"];
        if(!file_exists("decode.txt"))
        {
            $fp = fopen("decode.txt", "w+");
            foreach ($arrsplit as $val)
            {
                fwrite($fp, $val."split");
            }
            fclose($fp);
        }
    $encode = $do->dynamicCode();//获取动态加密编码
    $_SESSION["dynamicEncode"][] = $encode;//存入session
    //file_put_contents("dynamicEncode.txt", $_SESSION["dynamicEncode"]);
    $arrsplit = $_SESSION["dynamicEncode"];
        //if(!file_exists("decode.txt"))
        {
            $fp = fopen("dynamicEncode.txt", "w+");
            foreach ($arrsplit as $key=>$val)
            {
                
                foreach ($val as $k=>$v)
                {
                    fwrite($fp, $v."split");
                }
                fwrite($fp, "flag");
            }
            fclose($fp);
        }
    $result = $do->encode($encode);//加密后的编码数组
    $_SESSION["lastContent"][] = $result;//存入session
    //file_put_contents("lastContent.txt", $_SESSION["lastContent"]);
    $arrsplit = $_SESSION["lastContent"];
        //if(!file_exists("decode.txt"))
        {
            $fp = fopen("lastContent.txt", "w+");
            foreach ($arrsplit as $key=>$val)
            {
                
                foreach ($val as $k=>$v)
                {
                    fwrite($fp, $v."split");
                }
                fwrite($fp, "flag");
            }
            fclose($fp);
        }
    $jiamidir = "/jiami";
    $jiemidir = "/jiemi";
    $content = "";
    foreach ($result as $val)
    {
        $content.=$val;
        
    }
    $createfile = $rootdir.$jiamidir.$destfile;
    $createfile = str_replace("/", "\\", $createfile);
    $posstr = strrchr($createfile,"\\");
    $pos = strlen($createfile)-strlen($posstr);
    $createdir = substr($createfile,0,$pos);
    
    echo "创建加密目录:".$createdir ."</br>";
    if(!file_exists($createdir))
    {
        mkdir($createdir,0777,true);
    }
    
    $handle = fopen($createfile, "w+");
    if($handle)
    {
        fwrite($handle, $content);
        fclose($handle);
    }
    
    $jiemifile = $rootdir.$jiemidir.$destfile;
    $jiemifile = str_replace("/", "\\", $jiemifile);
    $posstr = strrchr($jiemifile,"\\");
    $pos = strlen($jiemifile)-strlen($posstr);
    $jiemidir = substr($jiemifile,0,$pos);
    
    echo "创建解密目录:".$jiemidir."</br>";
    if(!file_exists($jiemidir))
    {
        mkdir($jiemidir,0777,true);
        //copy($content, $jiamidir);
    }else
    {
        
    }
    /*
    echo "</br>所有的不许加密文件名</br>";
    print_r($all);
    echo "</br>";
    */
    $_SESSION["jiemiFile"][] = $jiemifile;
    /*
    $arrsplit = $_SESSION["jiemiFile"];
        //if(!file_exists("jiemiFile.txt"))//因为是动态加密，所以文件必须每次更新
        {
            $fp = fopen("jiemiFile.txt", "a+");
            foreach ($arrsplit as $val)
            {
                fwrite($fp, $val."\n");
            }
            fclose($fp);
        }
    */
    $handle = fopen($jiemifile, "w+");
    if($handle)
    {
        fwrite($handle, "解密文件");
        fclose($handle);
    }
    //file_put_contents($newdir.$destfile, $content);
    
    echo "</br>加密的结果</br>";
    echo $content;
    //echo "</br>*************************</br>";
    
    
    
    /*******************************************
    $endresult =  $do->dynamicDecode($content);
    var_dump($endresult);
    echo "</br>**************************</br>";
    *********************************************/
    $i++;
    $donum++;
}
        $arrsplit = $_SESSION["jiemiFile"];
        //if(!file_exists("jiemiFile.txt"))//因为是动态加密，所以文件必须每次更新
        {
            $fp = fopen("jiemiFile.txt", "w+");
            foreach ($arrsplit as $val)
            {
                fwrite($fp, $val."split");
            }
            fclose($fp);
        }


//解密程序可以采用session或者文件缓存的方式，测试切换标志是jiemi.php文件中的$cachefla
echo "</br>**********************************session中的解密编码比较长，不打印编码啦***********************************</br>";
/*
if($_SESSION["dynamicEncode"]!=null)
{
    foreach ($_SESSION["dynamicEncode"] as $encode)
    {
        echo "<pre>";
        print_r($encode);
        echo "</pre>";
    }
}
*/
//echo "</br>*********************************************************************</br>";
echo "</br>************************************解密文件名称*********************************</br>";

if($_SESSION["jiemiFile"]!=null)
{
    foreach ($_SESSION["jiemiFile"] as $file)
    {
        echo "<pre>";
        echo ($file);
        echo "</pre>";
    }
}
echo "</br>*******************************文件加密结束！**************************************</br>";




